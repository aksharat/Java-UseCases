package com.deloitte;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MovieTicketDaoImpl implements MovieticketDao {
	private int id;	
	private String name;
	private String showdate;
	private String showtime;
	private String status;
	List<MovieTicketDaoImpl> movieList =new ArrayList<>();
	public MovieTicketDaoImpl(int id, String name, String showdate2, String showtime, String status) {
	
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShowdate() {
		return showdate;
	}
	public void setShowdate(String showdate) {
		this.showdate = showdate;
	}
	public String getShowtime() {
		return showtime;
	}
	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public void add() {
	
		movieList.add(new MovieTicketDaoImpl(id, name, showdate, showtime, status));
		
	}
	@Override
	public List<MovieTicketDaoImpl> get() {
		
		return movieList;
	}
	

}
