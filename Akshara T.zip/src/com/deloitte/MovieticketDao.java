package com.deloitte;

import java.util.List;

public interface MovieticketDao {

	void add();

	List<MovieTicketDaoImpl> get();

}
