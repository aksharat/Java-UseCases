package com.deloitte;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class MovieMain {
	private MovieticketDao mticket;
public MovieMain() {
	int id;
	System.out.println("Enter user id");
	Scanner sc=new Scanner(System.in);	
	while(true) {
	 id=sc.nextInt();
	System.out.println("Enter user name");
	String name=sc.nextLine();
	System.out.println("Enter show date");
	String showdate=sc.next();
	System.out.println("Enter showtime");
	String showtime=sc.next();
	System.out.println("status");
	String status=sc.next();
	mticket=new MovieTicketDaoImpl(id,name,showdate,showtime,status);
	mticket.add();
	if(id==0) break;
	}
	System.out.println("enter id");
	int userid=sc.nextInt();
	if(userid==id) {
		System.out.println(mticket.get());
	}
	
}
	public static void main(String[] args) {
		new MovieMain();

	}

}
